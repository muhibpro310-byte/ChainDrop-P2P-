# ChainDrop — Secure P2P File Transfer

A simple, well-commented demo of secure peer-to-peer file transfer with
real-time activity broadcasting and blockchain-style logging.

## How to Run

1. Extract this folder.
2. Double-click `START.bat` (Windows) — it installs dependencies and starts
   the server, then opens your browser automatically.

   Or manually:
   ```
   pip install flask flask-socketio cryptography
   python app.py
   ```

3. Open **http://localhost:5000** in 5–6 browser tabs.
4. In each tab, type a different username and click "Join Network".

## Project Structure

```
ChainDrop_Clean/
├── app.py              <- Server logic (heavily commented, organized into sections)
├── requirements.txt    <- Python dependencies
├── START.bat           <- One-click launcher for Windows
└── templates/
    └── index.html      <- The webpage / GUI (also heavily commented)
```

## How It Works (Quick Tour)

- **Join Network**: Each browser tab picks a username and "joins" — appears
  in everyone's peer list.
- **Send File**: Select a peer, pick a file. The file is hashed (SHA-256),
  encrypted (AES-256-GCM), split into 64KB chunks, and streamed through the
  server to the receiver.
- **Live Activity Feed** (right sidebar): Everyone sees every event —
  who's sending what to whom, the file's hash, progress, and the final
  verification result. **Only sender and receiver ever see the file content.**
- **Network Check tab**: Shows server status, peer count, and blockchain
  validity — a simple "is everything healthy?" dashboard.
- **Blockchain tab**: Every completed transfer becomes a permanent
  "block" containing the file's hash, linked to the block before it.
- **Private Chat tab**: End-to-end encrypted messages between you and your
  selected peer. Others only see "a message was sent", not its content.

## Where Files Are Saved

When a receiver accepts and the transfer completes, the decrypted file
is automatically downloaded through the browser (to your normal Downloads
folder). The activity feed also shows the recorded save path and the
original sender (file "owner") for that record.

## Notes

- All data (peers, transfers, blockchain) lives in server memory only —
  it resets when you restart `app.py`. This is intentional for a clean demo.
- Designed for up to 6 concurrent users (shown in the Network Check tab).
